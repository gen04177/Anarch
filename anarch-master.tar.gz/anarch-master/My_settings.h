// Pokitto config required by PokittoLib

//#define PROJ_SHOW_FPS_COUNTER
#define PROJ_SCREENMODE 13
#define PROJ_MODE13 1
#define PROJ_ENABLE_SOUND 1

ANARCH MODS

All mods here are created solely by drummyfish and released under the same terms
as Anarch, i.e. completely public domain (CC0).

Single file mods are right in this directory, multiple file mods are in their
own subdirectory.

Most mods are diffs and can easily be installed with "git apply", the suckless
way. The diffs sometimes have comments in them with details about the mod.
